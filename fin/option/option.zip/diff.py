# -*- coding: utf-8 -*-

import os, re, datetime, gc
import pandas as pd
import mplfinance as mpf
import matplotlib.pyplot as plt
import seaborn as sn

from lutils.fin.data_loader import load

QT_TICK_ROOT = 'Z:/tq_data/ticks'

symbols_keep = ['SHFE.rb', 'SHFE.al', 'DCE.v', 'DCE.pp', 'DCE.m', 'DCE.c', 'DCE.b', 'DCE.a', 'CZCE.ma']

# FUTURE_RE = '[A-Z]+\.[a-zA-Z]+(\d+)\.h5' #'[A-Z]+\.[a-zA-Z]+[0-9]+\.h5'

all_files = os.listdir(QT_TICK_ROOT)
all_files.sort()

def filter_futures():
    futures = []
    for file_name in all_files:
        match = re.findall(r'[A-Z]+\.[a-zA-Z]+(\d+)\.h5', file_name)
        if match and file_name.startswith('SHFE.rb'):
            year = match[0]
            if len(year) == 3:
                year = '2%s' % year
            year = int(year)
            if year > 2305 or year < 2105:
                pass
            else:
                futures.append(file_name)
    return futures



def filter_options():
    futures = filter_futures()
    future_options = {}
    for future in futures:
        print(future)
        option_call_re = '%s\-?C\-?[0-9]+\.h5' % future[:-3]
        option_put_re = '%s\-?P\-?[0-9]+\.h5' % future[:-3]

        option_calls = []
        option_puts = []

        for file_name in all_files:
            match = re.findall(r'\S(\d+)\-?[C|P]\-?(\d+).h5', file_name)

            if match:
                [(year, price)] = match
                if len(year) == 3:
                    year = '2%s' % year
                year = int(year)
                price = int(price)

                match = re.match(option_call_re, file_name)
                if match:
                    exchange, symbol = file_name.split('.')[:2]
                    option_calls.append([exchange, symbol, year, price])

                match = re.match(option_put_re, file_name)
                if match:
                    exchange, symbol = file_name.split('.')[:2]
                    option_puts.append([exchange, symbol, year, price])

        option_calls.sort()
        option_puts.sort()

        future_options[future] = [option_calls, option_puts]
    return future_options


# mpf.plot(df,type='candle',style='yahoo',savefig=filename)
class Diff():

    def __init__(self, future, call_options, put_options, start_days=30):
        self.future = future
        self.call_options = call_options
        self.put_options = put_options

        self.exchange, self.symbol = self.future.split('.')[:2]
        self.start_days = start_days

        # self.underlying = None
        # self.calls = {}
        # self.puts = {}

        # self.load_data()

        self.hl_mean = 0

        self.load_data()
        self.sublect_hl_mean()
        self.iter_options()

    def sublect_hl_mean(self):

        self.underlying['hl'] = (self.underlying.high + self.underlying.low) / 2
        self.underlying['hl_mean'] = self.underlying.hl.rolling(self.start_days, min_periods=1).mean()

        start_time = self.underlying.iloc[-1].name - datetime.timedelta(days=(self.start_days - 10))

        self.hl_mean = self.underlying[self.underlying.index >= start_time].iloc[0].hl_mean
        self.hl_mean = self.hl_mean * 0.9


    def load_data(self):
        self.load_underlying()
        self.load_calls()
        # self.load_puts()


    def load_underlying(self):
        self.underlying = self.load_df(self.exchange, self.symbol)

    def load_calls(self):
        self.calls = {}
        for exchange, symbol, year, price in self.call_options:
            self.calls['%s.%s' % (exchange, symbol)] = self.load_df(exchange, symbol)

    def load_puts(self):
        self.puts = {}
        for exchange, symbol, year, price in self.put_options:
            self.puts['%s.%s' % (exchange, symbol)] = self.load_df(exchange, symbol)



    def load_df(self, exchange, symbol):
        df = load(exchange, symbol)
        df.index = df.datetime
        resample_ohlc_min = df['last_price'].resample('1Min', closed='left', label='right').ohlc(_method='ohlc')
        resample_volume_min = df['volume'].resample('1Min', closed='left', label='right').sum()
        resample_amount_min = df['amount'].resample('1Min', closed='left', label='right').sum()
        df_min = pd.concat([resample_ohlc_min, resample_volume_min, resample_amount_min], axis=1).dropna()

        return df_min


    def iter_options(self):

        for i, (exchange1, symbol1, year1, price1) in enumerate(self.call_options):
            if self.hl_mean and self.hl_mean > 0 and price1 > self.hl_mean:
                for (exchange2, symbol2, year2, price2) in self.call_options[i + 1:]:

                    print('%s.%s - %s.%s' % (exchange1, symbol1, exchange2, symbol2))

                    df1 = self.calls['%s.%s' % (exchange1, symbol1)]
                    df2 = self.calls['%s.%s' % (exchange2, symbol2)]

                    diff_df = df1.sub(df2).dropna() # 贵的 - 便宜的
                    if not diff_df.empty and diff_df.shape[0] > 12000:
                        self.saveflg(self.underlying, diff_df, '%s.%s' % (self.exchange, self.symbol), '%s.%s - %s.%s' % (exchange1, symbol1, exchange2, symbol2))


    
    def saveflg(self, df1, df2, df1_name, df2_name):
        c = df2.shape[0]
        fig = mpf.figure(style='yahoo', figsize=(12,9))
        # ax1 = fig.add_subplot(2, 1, 1)
        # ax2 = fig.add_subplot(2, 1, 2)

        ax1 = fig.add_subplot(3, 1, 1)
        ax2 = fig.add_subplot(3, 1, 2)
        ax3 = fig.add_subplot(3, 3, 7)
        ax4 = fig.add_subplot(3, 3, 8)
        ax5 = fig.add_subplot(3, 3, 9)

        end_time = df2.iloc[-1].name
        start_time = df2.iloc[-1].name - datetime.timedelta(days=35)

        _df1 = df1.loc[(df1.index > start_time) & (df1.index <= end_time)]
        _df2 = df2.loc[(df2.index > start_time) & (df2.index <= end_time)]

        _df1, _df2 = _df1.align(_df2, join="outer", axis=0)

        _df1 = _df1.ffill().bfill()
        _df2 = _df2.ffill().bfill()

        mpf.plot(_df1, ax=ax1, type='line', axtitle='%s %.02f %s %s' % (c, self.hl_mean, df1_name, df2_name), volume=False, mav=(3,6,9), figratio=(3,1), style='yahoo', datetime_format='%Y-%m-%d %H:%M')
        mpf.plot(_df2, ax=ax2, type='line', axtitle='', volume=False, mav=(3,6,9), figratio=(3,1), style='yahoo', datetime_format='%Y-%m-%d %H:%M')
        sn.distplot(_df2.close.diff(1), ax=ax3)
        sn.distplot(_df2.close.diff(1).iloc[int(_df2.shape[0] * .6):int(_df2.shape[0] * .9)], ax=ax4)
        sn.distplot(_df2.close.diff(1).iloc[int(_df2.shape[0] * .9):], ax=ax5)

        fig.savefig('D:/code/python/left5/fin/option/pic/%s %s+%s.png' % (c, df1_name, df2_name))

        fig.clear()
        plt.close()
        plt.cla()
        plt.clf()


def do():
    i = 0
    future_options = filter_options()
    for future, [option_calls, option_puts] in future_options.items():
        print('============== %s' % future)
        # print(option_calls)
        # print(option_puts)

        if len(option_calls) > 0 and len(option_puts) > 0:
            print('start option %s' % future)
            # print(option_calls, option_puts)
            di = Diff(future, option_calls, option_puts, start_days=30)

            gc.collect()
        else:
            print('not option %s' % future)




if __name__ == '__main__':
    do()

